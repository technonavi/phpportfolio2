<?php
$host = "localhost";
$port = "5432";
$db = "blog";
$user = "postgres";
$password = "postgres";

try {
    $pdo = new PDO("pgsql:host=$host;dbname=$db", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<script>console.log('Connected successfully');</script>"; // デバッグ用メッセージをブラウザのコンソールに表示
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>


