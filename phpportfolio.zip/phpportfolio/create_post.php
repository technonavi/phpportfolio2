<!DOCTYPE html>
<html>
<head>
    <title>新しいブログ投稿を作成</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="login-container">
    <h1>新しいブログ投稿を作成</h1>
    <form action="store_post.php" method="post">
        <label for="title">タイトル:</label>
        <input type="text" id="title" name="title" required>
        <br><br>
        <label for="content">内容:</label>
        <textarea id="content" name="content" rows="10" cols="30" required></textarea>
        <br><br>
        <button type="submit">投稿する</button>
    </form>
    <a href="index.php">戻る</a>
   </div>
</body>
</html>