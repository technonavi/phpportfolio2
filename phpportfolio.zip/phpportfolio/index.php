<?php
include 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$sql = 'SELECT * FROM posts ORDER BY created_at DESC';
$stmt = $pdo->query($sql);
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 現在の日付を取得
$currentDate = date('Y-m-d');
?>
<!DOCTYPE html>
<html>
<head>
    <title>ブログ</title>
    <link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body>
    <header>
        <h1>ブログ投稿一覧</h1>
        <p>こんにちは、<?php echo htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?>さん。</p>
        <nav>

            <a href="logout.php">ログアウト</a>
        </nav>
    </header>
    <div class="container">
        <a href="create_post.php">新しい投稿を作成</a>
        <?php foreach ($posts as $post): ?>
            <?php
                // 投稿の日付が今日の日付と一致するか確認
                $isNewPost = (date('Y-m-d', strtotime($post['created_at'])) == $currentDate);
            ?>
            <article class="<?php echo $isNewPost ? 'new-post' : ''; ?>">
                <h2><?php echo htmlspecialchars($post['title'], ENT_QUOTES, 'UTF-8'); ?></h2>
                <p><?php echo nl2br(htmlspecialchars($post['content'], ENT_QUOTES, 'UTF-8')); ?></p>
                <small>投稿日時: <?php echo $post['created_at']; ?></small>
                <form method="post" action="delete_post.php">
                    <input type="hidden" name="id" value="<?php echo $post['id']; ?>">
                    <button type="submit">削除</button>
                </form>
            </article>
            <hr>
        <?php endforeach; ?>
    </div>
</body>
</html>