<?php
include 'config.php';

$title = $_POST['title'];
$content = $_POST['content'];

$sql = 'INSERT INTO posts (title, content, created_at) VALUES (:title, :content, NOW())';
$stmt = $pdo->prepare($sql);
$stmt->execute(['title' => $title, 'content' => $content]);

header('Location: index.php');
exit();
?>